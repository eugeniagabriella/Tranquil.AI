import React from "react";

const Logo = () => {
  return <div className="text-lg font-semibold text-indigo-600">Trenquil</div>;
};

export default Logo;
